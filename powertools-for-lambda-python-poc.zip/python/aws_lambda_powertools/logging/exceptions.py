class InvalidLoggerSamplingRateError(Exception):
    pass
